<!DOCTYPE html>
<html>
<head>
	<title></title>
		<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	
	

	<style type="text/css">

			ul{
	list-style: none;
	text-decoration: none; 
	margin: 0px;
	background-color: #A7D3B5;
} 
ul li {
	display: inline-block;
	padding: 0px;
	margin-bottom: 20px;


}
ul li a{
 	text-decoration: none;
 	color: #fff;
 	padding:  10px 30px;
 	border: 1px solid #fff; 
 	transition: 0.20s ease;
}
ul li a:hover{
	color: #27B8B8;
	}

footer{
	background-color: #A7D3B5;
	font-size: 40px;
	color: #fff ;
	}
	h1{
		text-align: center;
	}
	h2{
		text-align: center;
	}
p{
	text-align: center;
	font-weight: bold;
}
.Messege{
	height: 70px;

}
input{
	text-align: left;
	width: 300px;
	background-color: white;
}
label{
	text-align: left;

}
textarea {
	width: 300px;
	height: 100px;
}
.gallery{
	width: 100px;
	height: 100px;
	margin-top: 20px;
	margin-bottom: 0px;
	margin-right: 700px;
}
.send{
	width: 100px;
	height: 50px;
	margin-right: 85px;
}
form{
	text-align: right;
	margin-right: 70%;
	font-weight: bold;


}
label{
	margin-right: 20px;
}





	</style>
</head>
<body>
	<div>
		<ul>
			<li><a href="home"><i class="fa fa-home"></i>&nbsp;HOME</a></li>
			<li><a href="about"><i class="fa fa-user"></i>&nbsp;ABOUT</a></li>
			<li><a href="contact"><i class="fa fa-phone"></i>&nbsp;CONTACT</a></li>

		</ul>
	</div>
	<div>
		 <h1>My Portfolio</h1>
	</div>
	<div>
		 <h2>Contact US </h2>	
		 <p> </p>
		 <form>
	 <label>Name:</label><input type="text" name="Name" placeholder="Name"><br>
		  <label>Email:</label><input type="text" name="Email" placeholder="Email" required="enter your Email" /><br>
		   <label>Subject:</label><input type="text" name="Subject" placeholder="Subject" required="whats  your  purpose"><br>
		    <label>Messege:</label><textarea placeholder="Messege" class="int" name="Messege" required="write  a Messege"></textarea><br>

		   <input type="submit" name="btn-send" placeholder="send" class="send">
		   </form>
	<center>
	<div>
		<footer>Despo</footer>
	</div>
	</center>
	

</body>
</html>